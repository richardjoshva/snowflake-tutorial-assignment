-- ============================================================
-- COMPLETE SNOWFLAKE TUTORIAL - ALL TASKS 1-5
-- ============================================================
-- Output examples are documented in assignment-report/Completion_Report.md
-- Do not upload Snowflake passwords or credentials.

-- ============================================================
-- TASK 1: Connection Verification
-- ============================================================

SELECT '========== TASK 1: CONNECTION VERIFICATION ==========' AS Step;
SELECT CURRENT_USER() AS Current_User;
SELECT CURRENT_ROLE() AS Current_Role;
SELECT CURRENT_WAREHOUSE() AS Current_Warehouse;
SELECT CURRENT_DATABASE() AS Current_Database;
SELECT CURRENT_SCHEMA() AS Current_Schema;


-- ============================================================
-- TASK 2: Create Snowflake Objects
-- ============================================================

SELECT '========== TASK 2: CREATING SNOWFLAKE OBJECTS ==========' AS Step;

CREATE OR REPLACE DATABASE tutorial_db;

CREATE OR REPLACE SCHEMA tutorial_db.tutorial_schema;

CREATE OR REPLACE WAREHOUSE tutorial_wh
  WAREHOUSE_SIZE = XSMALL
  AUTO_SUSPEND = 300
  AUTO_RESUME = TRUE;

USE DATABASE tutorial_db;
USE SCHEMA tutorial_schema;
USE WAREHOUSE tutorial_wh;

CREATE OR REPLACE TABLE employees (
    emp_id INTEGER,
    emp_name VARCHAR(100),
    department VARCHAR(50),
    salary DECIMAL(10,2),
    joining_date DATE
);

CREATE OR REPLACE STAGE my_stage;

SHOW DATABASES LIKE 'tutorial%';
SHOW SCHEMAS IN DATABASE tutorial_db;
SHOW WAREHOUSES LIKE 'tutorial%';
SHOW TABLES IN SCHEMA tutorial_schema;
SHOW STAGES IN SCHEMA tutorial_schema;

INSERT INTO employees (emp_id, emp_name, department, salary, joining_date) VALUES
(101, 'John Doe', 'Engineering', 75000.00, '2023-01-15'),
(102, 'Jane Smith', 'Marketing', 65000.00, '2023-02-20'),
(103, 'Bob Johnson', 'Engineering', 85000.00, '2023-03-10'),
(104, 'Alice Brown', 'Sales', 70000.00, '2023-04-05'),
(105, 'Charlie Wilson', 'HR', 55000.00, '2023-05-12');

SELECT 'Initial Data' AS Step, * FROM employees ORDER BY emp_id;

INSERT INTO employees (emp_id, emp_name, department, salary, joining_date)
VALUES (106, 'David Lee', 'IT', 80000.00, '2023-06-01');

UPDATE employees
SET salary = salary * 1.10
WHERE department = 'Engineering';

DELETE FROM employees
WHERE emp_id = 106;

SELECT 'After CRUD Operations' AS Step, * FROM employees ORDER BY emp_id;


-- ============================================================
-- TASK 3: Data Loading
-- ============================================================

SELECT '========== TASK 3: DATA LOADING ==========' AS Step;

INSERT INTO employees (emp_id, emp_name, department, salary, joining_date) VALUES
(201, 'Sarah Connor', 'Finance', 82000.00, '2023-07-15'),
(202, 'Mike Ross', 'Legal', 90000.00, '2023-08-20'),
(203, 'Rachel Zane', 'Marketing', 68000.00, '2023-09-10'),
(204, 'Harvey Specter', 'Legal', 95000.00, '2023-10-05'),
(205, 'Louis Litt', 'Finance', 72000.00, '2023-11-12');

SELECT 'After Data Loading' AS Step, * FROM employees ORDER BY emp_id;
SELECT COUNT(*) AS total_records FROM employees;


-- ============================================================
-- TASK 4 & 5: TIME TRAVEL AND DATA RECOVERY
-- ============================================================

USE DATABASE tutorial_db;
USE SCHEMA tutorial_schema;
USE WAREHOUSE tutorial_wh;

SELECT 'CURRENT DATA' AS Step, * FROM employees ORDER BY emp_id;

UPDATE employees
SET salary = salary * 1.10
WHERE department = 'Engineering';

DELETE FROM employees
WHERE emp_id IN (104, 105);

SELECT 'AFTER CHANGES' AS Step, * FROM employees ORDER BY emp_id;

-- Wait about 30 seconds, then run the Time Travel query.
SELECT 'TIME TRAVEL (60 seconds ago)' AS Step, *
FROM employees
BEFORE (OFFSET => -60)
ORDER BY emp_id;

-- Recover the records deleted above.
INSERT INTO employees
SELECT *
FROM employees
BEFORE (OFFSET => -60)
WHERE emp_id IN (104, 105);

SELECT 'AFTER RECOVERY' AS Step, * FROM employees ORDER BY emp_id;

SELECT COUNT(*) AS total_records FROM employees;

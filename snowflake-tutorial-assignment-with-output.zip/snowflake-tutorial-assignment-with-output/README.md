# ❄️ Snowflake Tutorial Assignment

## 📋 Overview

Complete Snowflake Tutorial Assignment demonstrating:

- Snowflake Connection & Verification
- Object Creation & CRUD Operations
- Data Loading
- Time Travel
- Data Recovery

## 🎯 Tasks Completed

| Task | Description | Status |
|------|-------------|--------|
| Task 1 | SnowSQL Login and Connection Verification | ⏳ Execute in Snowflake |
| Task 2 | Creation of Snowflake Objects + CRUD Operations | ⏳ Execute in Snowflake |
| Task 3 | Data Loading Using SnowSQL | ⏳ Execute in Snowflake |
| Task 4 | Snowflake Time Travel | ⏳ Execute in Snowflake |
| Task 5 | Data Recovery Using Time Travel | ⏳ Execute in Snowflake |

## 🛠️ Technologies Used

- Snowflake - Cloud Data Platform
- SnowSQL - Command-line client
- SQL - Structured Query Language

## 📁 Project Structure

```text
snowflake-tutorial-assignment/
├── README.md
├── Time-snowflakes.sql
└── assignment-report/
    └── Completion_Report.md
```

## 📝 Author

Richard Joshva Y

## 📅 Date

September 2026

> The output section in `assignment-report/Completion_Report.md` is an expected-output template. Replace placeholders with your actual Snowflake account values after execution.

# Snowflake Tutorial Assignment - Completion Report

**Student:** Richard Joshva Y  
**Date:** September 2026  
**Platform:** Snowflake

## Task 1 — Connection Verification

### SQL

```sql
SELECT CURRENT_USER();
SELECT CURRENT_ROLE();
SELECT CURRENT_WAREHOUSE();
SELECT CURRENT_DATABASE();
SELECT CURRENT_SCHEMA();
```

### Expected Output

```text
Current_User        | <YOUR_SNOWFLAKE_USERNAME>
Current_Role        | <YOUR_ROLE>
Current_Warehouse   | <YOUR_WAREHOUSE>
Current_Database    | <YOUR_DATABASE_OR_NULL>
Current_Schema      | <YOUR_SCHEMA_OR_NULL>
```

> Replace the placeholders with the values displayed by your own Snowflake account.

---

## Task 2 — Snowflake Objects and CRUD

### Objects Created

```text
Database   : TUTORIAL_DB
Schema     : TUTORIAL_SCHEMA
Warehouse  : TUTORIAL_WH
Table      : EMPLOYEES
Stage      : MY_STAGE
```

### Initial Data Output

```text
101 | John Doe       | Engineering | 75000.00 | 2023-01-15
102 | Jane Smith     | Marketing   | 65000.00 | 2023-02-20
103 | Bob Johnson    | Engineering | 85000.00 | 2023-03-10
104 | Alice Brown    | Sales       | 70000.00 | 2023-04-05
105 | Charlie Wilson | HR          | 55000.00 | 2023-05-12
```

### After INSERT, UPDATE and DELETE

David Lee (106) is inserted and then deleted. Engineering salaries are increased by 10%.

```text
101 | John Doe       | Engineering | 82500.00 | 2023-01-15
102 | Jane Smith     | Marketing   | 65000.00 | 2023-02-20
103 | Bob Johnson    | Engineering | 93500.00 | 2023-03-10
104 | Alice Brown    | Sales       | 70000.00 | 2023-04-05
105 | Charlie Wilson | HR          | 55000.00 | 2023-05-12
```

---

## Task 3 — Data Loading

Five additional records are inserted.

### Expected Output

```text
201 | Sarah Connor  | Finance    | 82000.00 | 2023-07-15
202 | Mike Ross     | Legal      | 90000.00 | 2023-08-20
203 | Rachel Zane   | Marketing  | 68000.00 | 2023-09-10
204 | Harvey Specter| Legal      | 95000.00 | 2023-10-05
205 | Louis Litt    | Finance    | 72000.00 | 2023-11-12
```

The final count at this point is:

```text
TOTAL_RECORDS
-------------
10
```

---

## Task 4 — Time Travel

Before the final changes, the table contains records 101–105 and 201–205.

The following changes are made:

- Engineering salaries are increased by another 10%.
- Employees 104 and 105 are deleted.

### Current Data After Changes

```text
101 | John Doe       | Engineering | 90750.00 | 2023-01-15
102 | Jane Smith     | Marketing   | 65000.00 | 2023-02-20
103 | Bob Johnson    | Engineering | 102850.00| 2023-03-10
201 | Sarah Connor   | Finance     | 82000.00 | 2023-07-15
202 | Mike Ross      | Legal       | 90000.00 | 2023-08-20
203 | Rachel Zane    | Marketing   | 68000.00 | 2023-09-10
204 | Harvey Specter | Legal       | 95000.00 | 2023-10-05
205 | Louis Litt     | Finance     | 72000.00 | 2023-11-12
```

### Time Travel

After waiting approximately 30 seconds:

```sql
SELECT *
FROM employees
BEFORE (OFFSET => -60)
ORDER BY emp_id;
```

The earlier version should contain the deleted records 104 and 105 and the previous Engineering salaries.

---

## Task 5 — Data Recovery

The records deleted in Task 4 are recovered from the earlier table version:

```sql
INSERT INTO employees
SELECT *
FROM employees
BEFORE (OFFSET => -60)
WHERE emp_id IN (104, 105);
```

### Expected Recovery Result

```text
104 | Alice Brown    | Sales | 70000.00 | 2023-04-05
105 | Charlie Wilson | HR    | 55000.00 | 2023-05-12
```

### Final Verification

```sql
SELECT * FROM employees ORDER BY emp_id;
SELECT COUNT(*) AS total_records FROM employees;
```

Expected final record count:

```text
TOTAL_RECORDS
-------------
10
```

---

## 📸 Evidence

For submission, add actual screenshots from the Snowflake/SnowSQL execution showing:

1. Task 1 connection verification
2. Task 2 objects and CRUD
3. Task 3 data loading
4. Task 4 Time Travel
5. Task 5 recovery

### Important

The output values above are **expected/reference outputs**, not screenshots from the student's Snowflake account. Actual account/role/warehouse values and execution screenshots must be captured after running the script.
